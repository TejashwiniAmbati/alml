import matplotlib.pyplot as plt

data = [1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 6]

plt.boxplot(data)
plt.xlabel('X-axis')
plt.ylabel('Values')
plt.title('Simple Box Plot')
plt.show()
