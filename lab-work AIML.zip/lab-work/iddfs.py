def dls(graph, start, goal, depth, visited=None):
    if visited is None:
        visited = set()
    if depth == 0 and start == goal:
        return True
    if depth > 0:
        for next_vertex in graph[start]:
            if next_vertex not in visited:
                visited.add(next_vertex)
                if dls(graph, next_vertex, goal, depth-1, visited):
                    return True
                visited.remove(next_vertex)
    return False

def iddfs(graph, start, goal):
    depth = 0
    while True:
        visited = set()
        if dls(graph, start, goal, depth, visited):
            return True
        depth += 1
    return False

iddfs(graph, 'A', 'F') 
